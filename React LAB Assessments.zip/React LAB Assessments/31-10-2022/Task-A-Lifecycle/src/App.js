import './App.css';
import Parent from './Parent';

function App() {
  return (
    <div className="App">
      <h1>Life Cycle</h1>
      <Parent/>
    </div>
  );
}

export default App;
