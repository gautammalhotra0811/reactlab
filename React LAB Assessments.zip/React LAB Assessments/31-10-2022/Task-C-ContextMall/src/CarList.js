import React from "react";
import Cars from "./Cars";

function CarList(props) {
  return (
    <div>
      <h2>CarList</h2>
      <Cars />
    </div>
  );
}

export default CarList;
