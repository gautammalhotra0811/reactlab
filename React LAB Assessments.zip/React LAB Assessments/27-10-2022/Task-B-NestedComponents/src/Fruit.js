import FruitType from './FruitType';

function Fruit() {
    return ( 
        <FruitType />
     );
}

export default Fruit;